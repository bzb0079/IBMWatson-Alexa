'use strict';

const AssistantV1 = require('watson-developer-cloud/assistant/v1');
const request = require('request');

let assistant;
let context;

function assistantMessage(request, workspaceId) {
  return new Promise(function(resolve, reject) {
    const input = (request && request.intent) ? request.intent.slots.EveryThingSlot.value : '';

    assistant.message(
      {
        input: { text: input },
        workspace_id: workspaceId,
        context: context
      },
      function(err, watsonResponse) {
        if (err) {
          console.error(err);
          reject('Error talking to Watson.');
        } else {
          context = watsonResponse.context;
		  watsonResponse.input
          resolve(watsonResponse);
        }
      }
    );
  });
}
function sendResponse(inputArgs, response, resolve) {
  const response_msg = response.output.text 
					 ? response.output.text.join(" ") 
					 : "no response values return by watson";
  resolve({
    version: '1.0',
    response: {
      shouldEndSession: false,
	  inputArgsObject: inputArgs,
	  watsonResponseObject: response,
      outputSpeech: {
        type: 'PlainText',
        text: response_msg,
      }
    }
  });
}
function main(args) {
	const rawBody = Buffer.from(args.__ow_body, 'base64').toString('ascii');
    const body = JSON.parse(rawBody);
    const sessionId = body.session.sessionId;
    const request = body.request;
	
	return new Promise(function(resolve, reject) {		
		assistant = new AssistantV1({
		  version: '2018-02-16',
		  username: args.ASSISTANT_USERNAME,
		  password: args.ASSISTANT_PASSWORD
		});

		assistantMessage(request, args.WORKSPACE_ID)
		.then(watsonResponse => sendResponse(args, watsonResponse, resolve))
		.catch(err => {
			reject({
				version: '1.0',
				args: args,
				response: {
				  shouldEndSession: true,
				  outputSpeech: {
					type: 'PlainText',
					text: err,
				  }
				}
			});
		});
	});
}
exports.main = main;